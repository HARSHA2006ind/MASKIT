from PyQt6.QtWidgets import QWidget, QSizeGrip, QVBoxLayout
from PyQt6.QtCore import Qt, QPoint, QRect, QSize, pyqtSignal
from PyQt6.QtGui import QPainter, QColor, QRegion, QMouseEvent, QCursor, QPainterPath, QPen

class PrivacyMask(QWidget):
    # Signals
    clicked_signal = pyqtSignal(object) # emit self

    def __init__(self, shape_type="rectangle", start_opacity=50):
        super().__init__()
        self.shape_type = shape_type
        self.opacity_level = start_opacity / 100.0
        self.is_selected = False
        self.mask_color = "black" # "black" or "white"
        self.show_border = True
        
        # Window Flags for Overlay
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint | 
            Qt.WindowType.WindowStaysOnTopHint | 
            Qt.WindowType.Tool  # Hides from taskbar
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        # Default size and position
        self.setGeometry(100, 100, 300, 200)
        self.setMinimumSize(50, 50)
        
        # Dragging state
        self.dragging = False
        self.drag_position = QPoint()
        
        # Resize Grip (Bottom Right)
        self.grip = QSizeGrip(self)
        self.grip.resize(20, 20)
        self.grip.setVisible(False) # Hidden by default until selected
        self.layout_grip()
        
        # Show immediately
        self.show()

    def layout_grip(self):
        # Position grip at bottom right
        self.grip.move(self.width() - 20, self.height() - 20)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Color: Black or White with alpha
        if self.mask_color == "white":
            color = QColor(255, 255, 255, int(255 * self.opacity_level))
        else:
            color = QColor(0, 0, 0, int(255 * self.opacity_level))
        painter.setBrush(color)
        
        # --- SELECTION INDICATOR ---
        if self.is_selected and self.show_border:
            # Solid Blue/Cyan Border for clear selection visibility
            selection_color = QColor("#5c9aff") 
            selection_pen = QPen(selection_color, 3, Qt.PenStyle.SolidLine)
            selection_pen.setJoinStyle(Qt.PenJoinStyle.MiterJoin)
            painter.setPen(selection_pen)
            
            # Draw rect around the edge
            painter.drawRect(self.rect().adjusted(2,2,-2,-2))
            
            # Reset pen for shape drawing
            painter.setPen(Qt.PenStyle.NoPen)
        else:
            painter.setPen(Qt.PenStyle.NoPen)
        
        # --- SHAPE DRAWING ---
        rect = self.rect()
        w = rect.width()
        h = rect.height()
        
        # Define a safe content area relative to the widget size
        # Minimize margin so shapes fill the window "at any size"
        safe_margin = 6 # Fixed small margin
        safe_rect = rect.adjusted(safe_margin, safe_margin, -safe_margin, -safe_margin)
        
        if self.shape_type == "circle":
            painter.drawEllipse(safe_rect)
            
        else:
            # Rectangle
            painter.drawRect(safe_rect)
            
    def update_opacity(self, value):
        self.opacity_level = value / 100.0
        self.update() # Trigger repaint
        
    def set_shape(self, shape):
        self.shape_type = shape
        self.update()
        
    def set_color(self, color_name):
        self.mask_color = color_name
        self.update()

    def set_show_border(self, show):
        self.show_border = show
        self.grip.setVisible(self.is_selected and self.show_border)
        self.update()
        
    def set_selected(self, selected):
        self.is_selected = selected
        self.grip.setVisible(self.is_selected and self.show_border)
        self.update()
        
    # --- Dragging Logic ---
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked_signal.emit(self) # Notify main controller we are clicked
            self.dragging = True
            self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event: QMouseEvent):
        if self.dragging:
            self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent):
        self.dragging = False

    def resizeEvent(self, event):
        self.layout_grip()
        super().resizeEvent(event)
