from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
from PyQt6.QtCore import QThread, pyqtSignal
import os
import socket
import qrcode
import io

# --- Data Models ---
class OpacityPayload(BaseModel):
    value: int

class ShapePayload(BaseModel):
    type: str

class TogglePayload(BaseModel):
    hide: bool

class ColorPayload(BaseModel):
    color: str

class BorderPayload(BaseModel):
    show: bool

# --- Server Logic ---
class LocalServer:
    def __init__(self):
        self.app = FastAPI()
        
        # Enable CORS just in case
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # We need a way to signal back to the main thread
        # This will be injected by the QThread wrapper
        self.signal_emitter = None 

        self.setup_routes()

    def set_emitter(self, emitter):
        self.signal_emitter = emitter

    def setup_routes(self):
        @self.app.get("/api/status")
        async def get_status():
            return {"status": "online", "message": "Privacy Shield Remote Active"}

        @self.app.post("/api/opacity")
        async def set_opacity(payload: OpacityPayload):
            if self.signal_emitter:
                self.signal_emitter.command_received.emit("opacity", payload.value)
            return {"status": "ok", "value": payload.value}

        @self.app.post("/api/shape")
        async def set_shape(payload: ShapePayload):
            if self.signal_emitter:
                self.signal_emitter.command_received.emit("shape", payload.type)
            return {"status": "ok", "shape": payload.type}

        @self.app.post("/api/color")
        async def set_color(payload: ColorPayload):
            if self.signal_emitter:
                self.signal_emitter.command_received.emit("color", payload.color)
            return {"status": "ok", "color": payload.color}

        @self.app.post("/api/border")
        async def set_border(payload: BorderPayload):
            if self.signal_emitter:
                self.signal_emitter.command_received.emit("border", payload.show)
            return {"status": "ok", "border": payload.show}

        @self.app.post("/api/toggle")
        async def toggle_visibility(payload: TogglePayload):
            if self.signal_emitter:
                self.signal_emitter.command_received.emit("toggle", payload.hide)
            return {"status": "ok", "hidden": payload.hide}
        
        @self.app.post("/api/mask/add")
        async def add_mask():
            if self.signal_emitter:
                self.signal_emitter.command_received.emit("add_mask", None)
            return {"status": "ok"}

        @self.app.delete("/api/mask/delete")
        async def delete_mask():
            if self.signal_emitter:
                self.signal_emitter.command_received.emit("delete_mask", None)
            return {"status": "ok"}

        # Serve Static Files (The Web App)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        web_dir = os.path.join(os.path.dirname(current_dir), "web")
        
        if os.path.exists(web_dir):
            self.app.mount("/", StaticFiles(directory=web_dir, html=True), name="static")
        else:
            print(f"Warning: Web directory not found at {web_dir}")

# --- Qt Thread Wrapper ---
class ServerThread(QThread):
    # Signal: command_type, value (can be int, str, bool, or None)
    command_received = pyqtSignal(str, object) 

    def __init__(self, host="0.0.0.0", port=8000):
        super().__init__()
        self.host = host
        self.port = port
        self.server_instance = LocalServer()
        self.server_instance.set_emitter(self)

    def run(self):
        # Determine local IP for logging purposes
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            url = f"http://{local_ip}:{self.port}"
            print(f"\n{'='*40}")
            print(f"REMOTE CONTROL URL: {url}")
            print(f"{'='*40}")
            
            # Generate and Print QR Code
            qr = qrcode.QRCode()
            qr.add_data(url)
            qr.make()
            print("\nScan this QR Code with your phone:")
            qr.print_ascii(invert=True)
            print("\n")
            
        except Exception as e:
            print(f"Could not determine IP or generate QR: {e}")
            print(f"Please manually try: http://localhost:{self.port}")

        # Run Uvicorn
        uvicorn.run(self.server_instance.app, host=self.host, port=self.port, log_level="info")
