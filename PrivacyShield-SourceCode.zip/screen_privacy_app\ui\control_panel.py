from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                             QSlider, QLabel, QRadioButton, QButtonGroup, QFrame)
from PyQt6.QtCore import Qt, pyqtSignal

class ControlPanel(QWidget):
    # Signals to communicate with the main controller
    add_mask_signal = pyqtSignal(str)  # shape_type
    update_opacity_signal = pyqtSignal(int)
    toggle_visibility_signal = pyqtSignal(bool)
    background_clicked_signal = pyqtSignal()
    delete_mask_signal = pyqtSignal()
    shape_changed_signal = pyqtSignal(str) # New signal for live update
    color_changed_signal = pyqtSignal(str) # New signal for mask color
    show_border_changed_signal = pyqtSignal(bool) # New signal for border visibility
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Privacy Shield - Control")
        # Wider and Taller for better text visibility and new options
        self.setFixedSize(420, 700) 
        self.setWindowFlags(Qt.WindowType.WindowStaysOnTopHint) # Keep control panel on top
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        # Reduced margins to give content more room
        layout.setContentsMargins(25, 25, 25, 25)
        
        # Header
        header = QLabel("Privacy Shield")
        header.setObjectName("Header")
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(header)
        
        # Shape Selection Group
        shape_group = QFrame()
        shape_layout = QVBoxLayout(shape_group)
        shape_layout.setSpacing(10)
        
        shape_label = QLabel("SHAPE")
        shape_label.setObjectName("SmallLabel")
        shape_layout.addWidget(shape_label)
        
        # Shape Buttons Grid
        # Row 1: Basic
        row1 = QHBoxLayout()
        row1.setSpacing(10)
        self.btn_rect = QPushButton("RECTANGLE")
        self.btn_rect.setCheckable(True)
        self.btn_rect.setChecked(True)
        self.btn_rect.clicked.connect(lambda: self.set_shape_selection(self.btn_rect, "rectangle"))
        
        self.btn_circle = QPushButton("CIRCLE")
        self.btn_circle.setCheckable(True)
        self.btn_circle.clicked.connect(lambda: self.set_shape_selection(self.btn_circle, "circle"))
        
        row1.addWidget(self.btn_rect)
        row1.addWidget(self.btn_circle)
        
        shape_layout.addLayout(row1)
        layout.addWidget(shape_group)
        
        self.selected_shape_btn = self.btn_rect

        # Color Selection Group
        color_group = QFrame()
        color_layout = QVBoxLayout(color_group)
        color_layout.setSpacing(10)
        
        color_label = QLabel("MASK COLOR")
        color_label.setObjectName("SmallLabel")
        color_layout.addWidget(color_label)
        
        row_color = QHBoxLayout()
        row_color.setSpacing(10)
        self.btn_black = QPushButton("BLACK")
        self.btn_black.setCheckable(True)
        self.btn_black.setChecked(True)
        self.btn_black.clicked.connect(lambda: self.set_color_selection(self.btn_black, "black"))
        
        self.btn_white = QPushButton("WHITE")
        self.btn_white.setCheckable(True)
        self.btn_white.clicked.connect(lambda: self.set_color_selection(self.btn_white, "white"))
        
        row_color.addWidget(self.btn_black)
        row_color.addWidget(self.btn_white)
        color_layout.addLayout(row_color)
        layout.addWidget(color_group)

        # Border Visibility Group
        border_group = QFrame()
        border_layout = QVBoxLayout(border_group)
        border_layout.setSpacing(10)
        
        border_label = QLabel("BORDER VISIBILITY")
        border_label.setObjectName("SmallLabel")
        border_layout.addWidget(border_label)
        
        self.btn_show_border = QPushButton("SHOW ACTIVE BORDERS")
        self.btn_show_border.setCheckable(True)
        self.btn_show_border.setChecked(True)
        self.btn_show_border.clicked.connect(self.on_border_toggle)
        border_layout.addWidget(self.btn_show_border)
        layout.addWidget(border_group)
        
        # Opacity Control
        opacity_group = QFrame()
        opacity_layout = QVBoxLayout(opacity_group)
        opacity_layout.setSpacing(10)
        
        self.opacity_label = QLabel("OPACITY: 50%")
        self.opacity_label.setObjectName("SmallLabel")
        
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setMinimum(10)
        self.slider.setMaximum(100)
        self.slider.setValue(50)
        self.slider.valueChanged.connect(self.on_opacity_change)
        
        opacity_layout.addWidget(self.opacity_label)
        opacity_layout.addWidget(self.slider)
        layout.addWidget(opacity_group)
        
        layout.addStretch()
        
        # Action Buttons
        actions_layout = QVBoxLayout()
        actions_layout.setSpacing(12)
        
        btn_add = QPushButton("ADD MASK")
        btn_add.setCursor(Qt.CursorShape.PointingHandCursor)
        # Style override for primary action
        btn_add.setStyleSheet("""
            QPushButton {
                background-color: #5c9aff;
                color: #ffffff;
                border: none;
            }
            QPushButton:hover {
                background-color: #4a89e0;
            }
        """)
        btn_add.clicked.connect(self.on_add_mask)
        actions_layout.addWidget(btn_add)
        
        self.btn_delete = QPushButton("DELETE SELECTED")
        self.btn_delete.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_delete.clicked.connect(self.delete_mask_signal.emit)
        actions_layout.addWidget(self.btn_delete)
        
        self.btn_toggle = QPushButton("HIDE ALL")
        self.btn_toggle.setCheckable(True)
        self.btn_toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_toggle.clicked.connect(self.on_toggle_visibility)
        actions_layout.addWidget(self.btn_toggle)
        
        btn_quit = QPushButton("EXIT SYSTEM")
        btn_quit.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_quit.setStyleSheet("""
            QPushButton {
                color: #e0e0e0;
                border: 1px solid #d9534f;
                background-color: transparent;
            }
            QPushButton:hover {
                background-color: #d9534f;
                color: white;
            }
        """)
        btn_quit.clicked.connect(self.close)
        actions_layout.addWidget(btn_quit)
        
        layout.addLayout(actions_layout)

    def set_shape_selection(self, btn, shape_type):
        for b in [self.btn_rect, self.btn_circle]:
            b.blockSignals(True) # Prevent recursive loops
            b.setChecked(False)
            b.blockSignals(False)
            
        btn.blockSignals(True)
        btn.setChecked(True)
        btn.blockSignals(False)
        
        self.selected_shape_btn = btn
        # Notify controller to update active mask immediately
        self.shape_changed_signal.emit(shape_type)

    def set_selected_shape_silent(self, shape_type):
        # Update UI without triggering signal (called when selecting a mask)
        target_btn = self.btn_rect if shape_type == "rectangle" else self.btn_circle
        
        for b in [self.btn_rect, self.btn_circle]:
            b.blockSignals(True)
            b.setChecked(False)
            b.blockSignals(False)
            
        target_btn.blockSignals(True)
        target_btn.setChecked(True)
        target_btn.blockSignals(False)
        self.selected_shape_btn = target_btn

    def set_color_selection(self, btn, color_name):
        for b in [self.btn_black, self.btn_white]:
            b.blockSignals(True)
            b.setChecked(False)
            b.blockSignals(False)
            
        btn.blockSignals(True)
        btn.setChecked(True)
        btn.blockSignals(False)
        
        self.color_changed_signal.emit(color_name)

    def set_selected_color_silent(self, color_name):
        target_btn = self.btn_black if color_name == "black" else self.btn_white
        for b in [self.btn_black, self.btn_white]:
            b.blockSignals(True)
            b.setChecked(False)
            b.blockSignals(False)
            
        target_btn.blockSignals(True)
        target_btn.setChecked(True)
        target_btn.blockSignals(False)

    def on_border_toggle(self):
        is_checked = self.btn_show_border.isChecked()
        self.btn_show_border.setText("SHOW ACTIVE BORDERS" if is_checked else "HIDE ACTIVE BORDERS")
        self.show_border_changed_signal.emit(is_checked)

    def set_show_border_silent(self, show):
        self.btn_show_border.blockSignals(True)
        self.btn_show_border.setChecked(show)
        self.btn_show_border.setText("SHOW ACTIVE BORDERS" if show else "HIDE ACTIVE BORDERS")
        self.btn_show_border.blockSignals(False)

    def set_opacity_silent(self, value):
        # Update slider without emitting signal back to controller (avoids loops)
        self.slider.blockSignals(True)
        self.slider.setValue(value)
        self.slider.blockSignals(False)
        self.opacity_label.setText(f"OPACITY: {value}%")

    def on_opacity_change(self, value):
        self.opacity_label.setText(f"OPACITY: {value}%")
        self.update_opacity_signal.emit(value)
        
    def on_add_mask(self):
        shape = "rectangle"
        if self.btn_rect.isChecked(): shape = "rectangle"
        elif self.btn_circle.isChecked(): shape = "circle"
        
        self.add_mask_signal.emit(shape)
        
    def on_toggle_visibility(self):
        is_hidden = self.btn_toggle.isChecked()
        self.btn_toggle.setText("SHOW ALL" if is_hidden else "HIDE ALL")
        self.toggle_visibility_signal.emit(not is_hidden)

    def mousePressEvent(self, event):
        # If clicking simply on the panel (not a button), emit signal to deselect masks
        self.background_clicked_signal.emit()
        super().mousePressEvent(event)
