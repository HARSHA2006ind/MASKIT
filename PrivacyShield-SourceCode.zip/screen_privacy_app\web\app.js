const API_URL = "/api";

// Elements
const btnToggle = document.getElementById('btn-toggle');
const slider = document.getElementById('opacity-slider');
const opacityVal = document.getElementById('opacity-val');
const btnRect = document.getElementById('btn-rect');
const btnCircle = document.getElementById('btn-circle');
const btns = { rectangle: btnRect, circle: btnCircle };

const btnColorBlack = document.getElementById('btn-color-black');
const btnColorWhite = document.getElementById('btn-color-white');
const colorBtns = { black: btnColorBlack, white: btnColorWhite };

const btnBorder = document.getElementById('btn-border');

let isHidden = false;
let showBorders = true;

// --- API Calls ---

async function toggleVisibility() {
    isHidden = !isHidden;

    // Optimistic UI update
    updateToggleButton();

    try {
        await fetch(`${API_URL}/toggle`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ hide: isHidden })
        });
    } catch (e) {
        console.error("Failed to toggle", e);
    }
}

function updateToggleButton() {
    if (isHidden) {
        btnToggle.textContent = "SHOW ALL";
        btnToggle.style.backgroundColor = "rgba(92, 154, 255, 0.2)";
        btnToggle.style.border = "1px solid #5c9aff";
    } else {
        btnToggle.textContent = "HIDE ALL";
        btnToggle.style.backgroundColor = "#5c9aff";
        btnToggle.style.border = "none";
    }
}

async function setOpacity(val) {
    opacityVal.textContent = val + "%";
    try {
        await fetch(`${API_URL}/opacity`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ value: parseInt(val) })
        });
    } catch (e) {
        console.error("Failed to set opacity", e);
    }
}

async function setShape(type) {
    // UI Update
    Object.values(btns).forEach(b => b.classList.remove('active'));
    btns[type].classList.add('active');

    try {
        await fetch(`${API_URL}/shape`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: type })
        });
    } catch (e) {
        console.error("Failed to set shape", e);
    }
}

async function setColor(color) {
    Object.values(colorBtns).forEach(b => b.classList.remove('active'));
    colorBtns[color].classList.add('active');

    try {
        await fetch(`${API_URL}/color`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ color: color })
        });
    } catch (e) {
        console.error("Failed to set color", e);
    }
}

async function toggleBorder() {
    showBorders = !showBorders;
    if (showBorders) {
        btnBorder.textContent = "SHOW ACTIVE BORDERS";
        btnBorder.style.backgroundColor = "#5c9aff";
        btnBorder.style.border = "none";
    } else {
        btnBorder.textContent = "HIDE ACTIVE BORDERS";
        btnBorder.style.backgroundColor = "rgba(92, 154, 255, 0.2)";
        btnBorder.style.border = "1px solid #5c9aff";
    }

    try {
        await fetch(`${API_URL}/border`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ show: showBorders })
        });
    } catch (e) {
        console.error("Failed to toggle borders", e);
    }
}

async function addMask() {
    try {
        await fetch(`${API_URL}/mask/add`, { method: 'POST' });
    } catch (e) { console.error(e); }
}

async function deleteMask() {
    try {
        await fetch(`${API_URL}/mask/delete`, { method: 'DELETE' });
    } catch (e) { console.error(e); }
}

// --- Event Listeners ---

btnToggle.addEventListener('click', toggleVisibility);

slider.addEventListener('input', (e) => {
    opacityVal.textContent = e.target.value + "%";
});

slider.addEventListener('change', (e) => {
    setOpacity(e.target.value);
});

// Initial Status Check
fetch(`${API_URL}/status`)
    .then(res => res.json())
    .then(data => {
        console.log("Server Online:", data);
        document.getElementById('status-indicator').style.color = "#2ecc71";
    })
    .catch(err => {
        console.warn("Server Offline");
        document.getElementById('status-indicator').style.color = "#e74c3c";
        document.getElementById('status-indicator').textContent = "DISCONNECTED";
    });

// --- Tab Logic ---
function switchTab(tabName) {
    // Update Tab UI
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    if (tabName === 'remote') document.querySelectorAll('.tab')[0].classList.add('active');
    else document.querySelectorAll('.tab')[1].classList.add('active');

    // Show/Hide Views
    if (tabName === 'remote') {
        document.getElementById('view-remote').style.display = 'block';
        document.getElementById('view-local').style.display = 'none';
        document.getElementById('status-indicator').style.display = 'block';
    } else {
        document.getElementById('view-remote').style.display = 'none';
        document.getElementById('view-local').style.display = 'block';
        document.getElementById('status-indicator').style.display = 'none';
    }
}

// --- Local Shield Logic ---
const localShield = document.getElementById('local-shield');

function toggleLocalShield() {
    localShield.classList.toggle('active');

    // Default opacity check
    const val = document.getElementById('local-opacity').value;
    updateLocalOpacity(val);
}

function updateLocalOpacity(val) {
    if (localShield.classList.contains('active')) {
        localShield.style.opacity = val / 100;
    } else {
        localShield.style.opacity = 0;
    }
}
