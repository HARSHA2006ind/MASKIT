import sys
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QObject, pyqtSignal
from ui.control_panel import ControlPanel
from ui.privacy_mask import PrivacyMask
from utils.styles import DARK_THEME
from utils.api_server import ServerThread
import keyboard

class PrivacyShieldApp(QObject):
    # Signal to handle hotkey event in main thread
    hotkey_triggered = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.app = QApplication(sys.argv)
        self.app.setStyleSheet(DARK_THEME)
        
        self.masks = []
        self.active_mask = None # Track which mask is selected for editing
        
        self.control_panel = ControlPanel()
        self.connect_signals()
        self.control_panel.show()
        
        # Setup Global Hotkey
        self.hotkey_triggered.connect(self.on_hotkey_toggle)
        try:
            keyboard.add_hotkey('ctrl+alt+h', self.hotkey_triggered.emit)
        except ImportError:
            print("Keyboard library not installed or permission denied.")

        # Start Remote Control Server
        self.server_thread = ServerThread()
        self.server_thread.command_received.connect(self.on_server_command)
        self.server_thread.start()
        
    def connect_signals(self):
        self.control_panel.add_mask_signal.connect(self.create_mask)
        self.control_panel.update_opacity_signal.connect(self.update_active_opacity)
        self.control_panel.toggle_visibility_signal.connect(self.toggle_visibility)
        self.control_panel.background_clicked_signal.connect(self.deselect_all_masks)
        self.control_panel.delete_mask_signal.connect(self.delete_selected_mask)
        self.control_panel.shape_changed_signal.connect(self.update_active_mask_shape)
        self.control_panel.color_changed_signal.connect(self.update_active_color)
        self.control_panel.show_border_changed_signal.connect(self.update_active_border_visibility)

    def on_server_command(self, cmd_type, value):
        """Handle commands from the mobile web app"""
        print(f"Server Command: {cmd_type} -> {value}")
        
        if cmd_type == "toggle":
            # Value is boolean (hide=True/False)
            is_currently_hidden = self.control_panel.btn_toggle.isChecked()
            if is_currently_hidden != value:
                self.control_panel.btn_toggle.click()
                
        elif cmd_type == "opacity":
            # Value is int 0-100
            self.control_panel.set_opacity_silent(value)
            self.update_active_opacity(value)
            
        elif cmd_type == "shape":
            # Value is "rectangle" or "circle"
            target_btn = self.control_panel.btn_rect if value == "rectangle" else self.control_panel.btn_circle
            self.control_panel.set_shape_selection(target_btn, value)

        elif cmd_type == "color":
            # Value is "black" or "white"
            self.control_panel.set_selected_color_silent(value)
            self.update_active_color(value)

        elif cmd_type == "border":
            # Value is boolean (True/False)
            self.control_panel.set_show_border_silent(value)
            self.update_active_border_visibility(value)
            
        elif cmd_type == "add_mask":
            curr_shape = "rectangle"
            if self.control_panel.btn_circle.isChecked():
                curr_shape = "circle"
            self.create_mask(curr_shape)
            
        elif cmd_type == "delete_mask":
            self.delete_selected_mask()
        
    def create_mask(self, shape_type):
        # Create a new mask with current settings
        current_opacity = self.control_panel.slider.value()
        mask = PrivacyMask(shape_type, current_opacity)
        
        # Connect click signal
        mask.clicked_signal.connect(self.on_mask_clicked)
        
        self.masks.append(mask)
        
        # Auto-select the new mask
        self.select_mask(mask)
        
    def on_mask_clicked(self, mask_obj):
        self.select_mask(mask_obj)

    def select_mask(self, mask):
        # Deselect others
        if self.active_mask and self.active_mask != mask:
            self.active_mask.set_selected(False)
            
        self.active_mask = mask
        self.active_mask.set_selected(True)
        
        # Update slider to match this mask's opacity without triggering update loop
        opacity_percent = int(mask.opacity_level * 100)
        self.control_panel.set_opacity_silent(opacity_percent)
        
        # Update Shape, Color, and Border Buttons to match selected mask
        self.control_panel.set_selected_shape_silent(mask.shape_type)
        self.control_panel.set_selected_color_silent(mask.mask_color)
        self.control_panel.set_show_border_silent(mask.show_border)

    def deselect_all_masks(self):
        if self.active_mask:
            self.active_mask.set_selected(False)
            self.active_mask = None
            
    def delete_selected_mask(self):
        if self.active_mask:
            self.masks.remove(self.active_mask)
            self.active_mask.close()
            self.active_mask = None

    def update_active_opacity(self, value):
        if self.active_mask:
            self.active_mask.update_opacity(value)
            
    def update_active_mask_shape(self, shape_type):
        if self.active_mask:
            self.active_mask.set_shape(shape_type)

    def update_active_color(self, color_name):
        if self.active_mask:
            self.active_mask.set_color(color_name)

    def update_active_border_visibility(self, show):
        if self.active_mask:
            self.active_mask.set_show_border(show)
            
    def toggle_visibility(self, should_hide):
        if should_hide:
            for mask in self.masks:
                mask.hide()
        else:
            for mask in self.masks:
                mask.show()

    def on_hotkey_toggle(self):
        self.control_panel.btn_toggle.click()
                
    def run(self):
        sys.exit(self.app.exec())
        
if __name__ == "__main__":
    controller = PrivacyShieldApp()
    controller.run()
