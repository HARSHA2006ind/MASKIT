from PIL import Image, ImageDraw, ImageFont
import os

def create_icon(size, filename):
    # Create a dark circle background
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Draw circle
    draw.ellipse([0, 0, size, size], fill='#18191c', outline='#5c9aff', width=int(size*0.05))
    
    # Draw Shield/Lock symbol (simplified as a rounded rect or just text 'P')
    # Let's draw a simple 'P'
    try:
        # Try to load a font, fallback to default
        font = ImageFont.truetype("arial.ttf", int(size*0.6))
    except:
        font = ImageFont.load_default()
        
    text = "P"
    
    # Measure text size (basic method for PIL < 10 or generic)
    # Using textbbox if available (Pillow 8+)
    try:
        left, top, right, bottom = draw.textbbox((0, 0), text, font=font)
        text_w = right - left
        text_h = bottom - top
    except:
        text_w, text_h = draw.textsize(text, font=font)

    x = (size - text_w) / 2
    y = (size - text_h) / 2 - (size * 0.05) # slight vertical adjust
    
    draw.text((x, y), text, font=font, fill='#5c9aff')
    
    img.save(f"web/{filename}")
    print(f"Generated {filename}")

if __name__ == "__main__":
    if not os.path.exists("web"):
        os.makedirs("web")
        
    try:
        create_icon(192, "icon.png")
        create_icon(512, "icon-512.png")
        print("Icons created successfully.")
    except ImportError:
        print("Pillow (PIL) not installed. Installing...")
        import subprocess
        subprocess.check_call(["pip", "install", "Pillow"])
        # Retry once
        create_icon(192, "icon.png")
        create_icon(512, "icon-512.png")

