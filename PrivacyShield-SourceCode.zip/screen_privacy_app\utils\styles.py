DARK_THEME = """
QWidget {
    background-color: #18191c;
    color: #e4e7eb;
    font-family: 'Segoe UI', 'Roboto', sans-serif;
    font-size: 14px;
}

/* Modern Professional Button */
QPushButton {
    background-color: #2b2d31;
    border: 1px solid #3f4147;
    border-radius: 6px;
    padding: 12px 16px;
    font-weight: 600;
    color: #e4e7eb;
    font-size: 13px;
    letter-spacing: 0.5px;
}

QPushButton:hover {
    background-color: #3f4147;
    border: 1px solid #5c9aff;
    color: #5c9aff;
}

QPushButton:pressed {
    background-color: #5c9aff;
    color: #ffffff;
}

QPushButton:checked {
    background-color: #202b3b; 
    color: #5c9aff;
    border: 1px solid #5c9aff;
}

/* Modern Slider */
QSlider::groove:horizontal {
    border: none;
    height: 4px;
    background: #3f4147;
    margin: 2px 0;
    border-radius: 2px;
}

QSlider::sub-page:horizontal {
    background: #5c9aff;
    border-radius: 2px;
}

QSlider::handle:horizontal {
    background: #ffffff;
    border: 2px solid #5c9aff;
    width: 18px;
    height: 18px;
    margin: -7px 0;
    border-radius: 9px;
}

QSlider::handle:horizontal:hover {
    background: #f0f0f0;
}

/* Styled Frames for grouping */
QFrame {
    border: none;
    background: transparent;
}

/* Header Label */
QLabel#Header {
    font-size: 22px;
    font-weight: 700;
    color: #ffffff;
    margin-bottom: 20px;
    letter-spacing: 1px;
    text-transform: uppercase;
}

/* General Labels */
QLabel {
    color: #9fa6b2; /* Muted text */
    font-size: 14px;
    font-weight: 500;
}

/* Small Caps Labels */
QLabel#SmallLabel {
    font-size: 11px; 
    font-weight: 700; 
    letter-spacing: 1px;
    color: #9fa6b2;
    text-transform: uppercase;
    margin-bottom: 5px;
}
"""
